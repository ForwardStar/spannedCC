#include "commonfunctions.h"
#include "temporal_graph.h"

void online(TemporalGraph * Graph, char * query_file, char * output_file);