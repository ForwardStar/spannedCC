# $1: the number of queries to generate

python3 -u query-gen.py $1